package com.example.amdocsP;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

public class demoP {

	public static void main(String[] args) {
		

			FirefoxDriver dr=new FirefoxDriver();
			dr.get("https://www.google.com");
	        dr.manage().window().maximize();
	        dr.findElement(By.id("APjFqb")).sendKeys("giva");
	        dr.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[4]/center/input[1]")).click();
	        dr.findElement(By.cssSelector(".CCgQ5 > span:nth-child(1)")).click();
	        dr.findElement(By.xpath("/html/body/div[2]/div/header/div/nav/ul/li[4]/a/span")).click();
	        dr.findElement(By.xpath("/html/body/div[3]/main/div[1]/div[1]/div[2]/div/div[2]/ul/div[1]/div[2]/a")).click();
	        dr.findElement(By.xpath("//*[@id=\"mst-stiky-box\"]")).click();
	        dr.findElement(By.xpath("/html/body/div[3]/main/div/div/form/div[2]/div/div[7]/button")).click();
	   
	 
	        
		}



	}

